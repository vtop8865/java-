package shujuku;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseDao {

	String driverClassName="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/user?serverTimezone=GMT";
	String username="root";
	String password="";
	Connection conn = null;
	public Statement stmt =null;
	{
	//加载驱动类
	try {
		Class.forName(driverClassName);
		System.out.println("驱动加载成功.......");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	//使用DriverManager获得Connection
	try {
		conn=DriverManager.getConnection(url,username,password);
		System.out.println("数据库连接成功........");
	} catch (SQLException e11) {
		e11.printStackTrace();
		System.out.println("数据库连接失败........");
	}
	try {
		 stmt=conn.createStatement();
		 System.out.println("实例化对象创建成功.......");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

