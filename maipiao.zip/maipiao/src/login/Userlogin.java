package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import shujuku.BaseDao;
@WebServlet("/Userlogin")
public class Userlogin extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.获得用户名密码
	
		//2.从数据库进行验证
		
		//3.根据返回结果回应用户
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//准备参数
		String uname=request.getParameter("username");
		String upwd=request.getParameter("password");
		BaseDao dao=new BaseDao();
		String sql;
		sql="select * from users where username='"+uname+"' and password='"+upwd+"'";
		ResultSet rs=null;		
		try {
			rs=dao.stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(rs.next()) {
				response.getWriter().write("ok");	
				HttpSession session = request.getSession(); 
				session.setAttribute("username", uname);				
			}
			else {
				response.getWriter().write("没有找到该用户");				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}

}
