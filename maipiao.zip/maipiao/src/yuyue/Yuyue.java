package yuyue;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import shujuku.BaseDao;



public class Yuyue extends HttpServlet {

       
  

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		response.setCharacterEncoding("UTF-8");
		BaseDao dao=new BaseDao();
		int rs=0;
		String zuowei=request.getParameter("zuowei");
		String str=request.getParameter("xianlu");
		int xianlu=	Integer.parseInt(str);
		HttpSession session = request.getSession(); 
		String username=(String) session.getAttribute("username");
		String sql;
		String sql2;
		sql="INSERT INTO yuyuepiao (username,xianlu,zuowei) VALUES ('"+username+"','"+xianlu+"','"+zuowei+"')"; 
		sql2="UPDATE checi SET piaoshu = piaoshu - 1 WHERE xianlu = '"+xianlu+"' ";
		if(username==null) {
			response.getWriter().write("请先登录,在选座位");				
		}
		else {
			try {
				dao.stmt.executeUpdate(sql);
				dao.stmt.executeUpdate(sql2);
				response.getWriter().write("ok");	
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	
	}

}
