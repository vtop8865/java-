package yuyue;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import shujuku.BaseDao;


@WebServlet("/Quxiaoyuyue")
public class Quxiaoyuyue extends HttpServlet {
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String sql;
		String sql2;
		String username=request.getParameter("username");
		String xianlu=request.getParameter("xianlu");
		sql="delete from yuyuepiao where username='"+username+"'and xianlu='"+xianlu+"'";	
		sql2="UPDATE checi SET piaoshu = piaoshu + 1 WHERE xianlu = '"+xianlu+"' ";
		BaseDao dao=new BaseDao();
		try {
			dao.stmt.executeUpdate(sql);
			dao.stmt.executeUpdate(sql2);
			response.getWriter().write("ok");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.getWriter().write("取消失败，请重试");
		}
	}

}
